import pytest
from api import PetFriends
from settings import *

@pytest.fixture()
def get_key():
   #self.pf = PetFriends()
   pf1 = PetFriends()
   status, key = pf1.get_api_key(my_mail, my_pass)
   assert status == 200
   assert 'key' in key
   return status, key

#@pytest.fixture(autouse=True)
   #autouse=True ответственен за то, что даже без упоминания в параметрах теста
   # эта функция будет автоматически запускаться! и название get_key_1 значения не имеет
#def get_key_1():
#   pf1 = PetFriends()
#   status, api_key = pf1.get_api_key(my_mail, my_pass)
#   assert status == 200
#   assert 'key' in api_key

#   yield

#   assert status == 200