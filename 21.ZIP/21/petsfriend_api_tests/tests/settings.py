my_mail = 'vol1@test.test'
my_pass = 'vol1'
api_key = "5402354a55655803bd34fe6b16344855c6056d34b7746bae11b2e990"
#api_key = ""
base_url = 'https://petfriends1.herokuapp.com/'